package main.database.java;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.text.SimpleDateFormat;
import java.util.HashSet;
import java.util.InvalidPropertiesFormatException;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * This class set up the connects to a MySQL Sever, creates a DB and a table and
 * give the user access permissions provides an API to run query with or without
 * parameters, update the table and add events from a DataList to the DB
 * 
 * @author osherh
 * @since 6/12/2016
 */
public class MySQLConnector {
	private static final Logger logger = Logger.getLogger("MySQLConnector".getClass().getName());
	private static Connection conn;
	private boolean dbExists;

	public MySQLConnector() throws Exception {
		try {
			conn = getConnection();
			logger.log(Level.INFO, "connected to server");
			runQuery("use sys");
		} catch (Exception ¢) {
			throw ¢;
		}
		try (ResultSet r = runQuery("SHOW DATABASES;");) {
			while (r.next())
				if ("events".equals(r.getString(1)))
					dbExists = true;
			if (!dbExists) {
				givePermissions();
				createDatabase();
				logger.log(Level.INFO, "database created succesfully");

			}
			runQuery("use events;");
		} catch (final SQLException ¢) {
			throw ¢;
		}
	}

	private Connection getConnection() throws SQLException, IOException, ClassNotFoundException {
		Properties props = new Properties();
		try {
			props.loadFromXML(getClass().getResourceAsStream("../resources/DatabaseConnectionProperties.xml"));
		} catch (InvalidPropertiesFormatException ¢) {
			throw ¢;
		}
		String $ = props.getProperty("jdbc.username");
		String password = props.getProperty("jdbc.password");
		String driver = props.getProperty("jdbc.driver");
		String host = props.getProperty("jdbc.host");

		try {
			Class.forName(driver);
		} catch (ClassNotFoundException ¢) {
			throw ¢;
		}
		try {
			return DriverManager.getConnection(host, $, password);
		} catch (SQLException ¢) {
			throw ¢;
		}
	}

	private void createDatabase() throws SQLException {
		runUpdate("CREATE database events");
		logger.log(Level.INFO, "DB events created successfully");
		runQuery("use events");
		runUpdate(
				"CREATE TABLE celebs_arrests (Name VARCHAR(30) NOT NULL,Arrest_Date DATE NOT NULL,Reason VARCHAR(400) NOT NULL,Keywords VARCHAR(200) NOT NULL,PRIMARY KEY (Name,Arrest_Date,Reason))");
		runUpdate("CREATE TABLE keywords_table (Keyword VARCHAR(70))");
		logger.log(Level.INFO, "tables celebs_arrests created successfully");
	}

	private void givePermissions() throws SQLException {
		runQuery("grant all privileges on *.* to root@localhost;");
	}

	public static int runUpdate(final String query) throws SQLException {
		return conn.createStatement().executeUpdate(query);
	}

	public static ResultSet runQuery(final String query) throws SQLException {
		return conn.createStatement().executeQuery(query);
	}

	public static ResultSet runQuery(final String query, final Object[] inputs) throws SQLException {
		PreparedStatement $ = conn.prepareStatement(query);
		for (int ¢ = 1; ¢ <= inputs.length; ++¢)
			$.setObject(¢, inputs[¢ - 1]);
		return $.executeQuery();
	}

	public static ResultSet runQuery(final String query, final Object input) throws SQLException {
		PreparedStatement $ = conn.prepareStatement(query);
		$.setObject(1, input);
		return $.executeQuery();
	}

	public static int runUpdate(final String query, final Object input) throws SQLException {
		PreparedStatement $ = conn.prepareStatement(query);
		$.setObject(1, input);
		return $.executeUpdate();
	}

	private static java.sql.Date utilDateToSQLDateConvertor(final java.util.Date utilDate) {
		return java.sql.Date.valueOf(new SimpleDateFormat("yyyy-MM-dd").format(utilDate));
	}

	public static void addEvents(final DataList lin) {
		for (final TableTuple tuple : lin)
			try (PreparedStatement ps = conn.prepareStatement("INSERT INTO celebs_arrests values (?,?,?,?);");) {
				ps.setString(1, tuple.getName());
				ps.setDate(2, utilDateToSQLDateConvertor(tuple.getRegularDate()));
				ps.setString(3, tuple.getReason());
				List<String> keywords = tuple.getKeyWords();
				String keywordsStr = "";
				for (String word : keywords)
					keywordsStr += word + " ";
				ps.setString(4, keywordsStr);
				ps.executeUpdate();
			} catch (final SQLException ¢) {
				¢.printStackTrace();
			}
	}

	public static void addAllKeywords(DataList lin) throws SQLException {
		Set<String> keywords = new HashSet<>();
		for (final TableTuple ¢ : lin)
			keywords.addAll(¢.getKeyWords());
		for (String keyword : keywords)
			runUpdate("INSERT INTO keywords_table VALUES(?)", keyword);
	}

	public static void clearDB() throws SQLException {
		runUpdate("DELETE FROM celebs_arrests");
		runUpdate("DELETE FROM keywords_table");
	}

	public static void closeConnection() {
		try {
			if (conn != null)
				conn.close();
		} catch (final SQLException ¢) {
			¢.printStackTrace();
		}
	}
}