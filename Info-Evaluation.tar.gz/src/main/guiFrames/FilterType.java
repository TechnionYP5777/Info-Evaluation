package main.guiFrames;

public enum FilterType {
	RIGHT_CLICK,
	CHOOSE_FROM_LIST,
	AUTOCOMPLETE
}

